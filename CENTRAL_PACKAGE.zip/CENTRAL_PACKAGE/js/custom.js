(function(){
"use strict";
'use strict';

var app = angular.module('centralCustom', ['angularLoad']);

/**
 * Collapse institution list in full record
 */

app.controller('institutionToggleController', ['$scope', function ($scope) {
    /**
     * On page load, hide libraries
     */
    this.$onInit = function () {
        $scope.showLibs = false;
        $scope.button = angular.element(document.querySelector('prm-alma-more-inst-after'));
        $scope.tabs = angular.element(document.querySelector('prm-alma-more-inst md-tabs'));
        $scope.tabs.addClass('hide');
        $scope.button.after($scope.tabs);
    };

    /**
     * Show or hide library based on previous state
     */
    $scope.toggleLibs = function () {
        $scope.showLibs = !$scope.showLibs;
        if ($scope.tabs.hasClass('hide')) $scope.tabs.removeClass('hide');else $scope.tabs.addClass('hide');
    };
}]);

app.component('prmAlmaMoreInstAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'institutionToggleController',
    templateUrl: 'custom/CENTRAL_PACKAGE/html/prmAlmaMoreInstAfter.html'
});

/**
 * Show logged in user's name under Sign Out
 */

app.component('prmAuthenticationAfter', {
    bindings: { parentCtrl: '<' },
    controller: function controller($compile, $scope, $templateCache, $element) {
        $templateCache.put('components/search/topbar/userArea/authentication.html', '\n\t\t  <div class="md-fab-toolbar-wrapper">\n\t\t  <md-button ng-if="!$ctrl.isLoggedIn" ng-click="$ctrl.handleLogin();" aria-label="{{\'eshelf.signin.title\' | translate}}" class="button-with-icon zero-margin">\n\t\t    <prm-icon icon-type="svg" svg-icon-set="primo-ui" icon-definition="sign-in"></prm-icon>\n\t\t    <span><span translate="eshelf.signin.title"></span></span></span>\n\t\t  </md-button>\n\t\t  <md-button ng-if="$ctrl.isLoggedIn" ng-click="$ctrl.handleLogout(authenticationMethod)" aria-label="{{\'eshelf.signout.title.link\' | translate}}" class="button-with-icon zero-margin authentication-multiline">\n\t\t    <prm-icon icon-type="svg" svg-icon-set="primo-ui" icon-definition="sign-out"></prm-icon>\n\t\t    <div class="layout-align-center-start layout-column">\n\t\t      <span translate="eshelf.signout.title.link"></span>\n\t\t      <span>{{$ctrl.loginService.userSessionManagerService.jwtUtilService.getDecodedToken().userName}}</span>\n\t\t    </div>\n\t\t  </md-button>');
        $compile($element.parent())($scope);
    }
});

/**
 * CSU OneSearch logo
 */

app.controller('prmSearchBarAfterController', ['$location', '$window', function ($location, $window) {
    /**
     * Navigates to the home page with a reload.
     * @return {boolean} Booelan value indicating if the navigation was successful.
     */
    this.navigateToHomePage = function () {
        var params = $location.search();
        var vid = params.vid;
        var lang = params.lang || "en_US";
        var split = $location.absUrl().split('/primo-explore/');

        if (split.length === 1) {
            console.log(split[0] + ' : Could not detect the view name!');
            return false;
        }

        var baseUrl = split[0];
        $window.location.href = baseUrl + '/primo-explore/search?vid=' + vid + '&lang=' + lang;
        return true;
    };

    /**
     * OneSearch logo
     * @return {string} URI to the one-search logo file in the current view
     */
    this.getOneSearchLogo = function () {
        var params = $location.search();
        var vid = params.vid.substring(0, 10);
        var campus = {};
        campus['01CALS_UBA'] = 'bakersfield';
        campus['01CALS_UCI'] = 'channel';
        campus['01CALS_CHI'] = 'chico';
        campus['01CALS_UDH'] = 'dominguez';
        campus['01CALS_UHL'] = 'eastbay';
        campus['01CALS_UFR'] = 'fresno';
        campus['01CALS_FUL'] = 'fullerton';
        campus['01CALS_HUL'] = 'humboldt';
        campus['01CALS_ULB'] = 'longbeach';
        campus['01CALS_ULA'] = 'losangeles';
        campus['01CALS_MAL'] = 'maritime';
        campus['01CALS_UMB'] = 'monterey';
        campus['01CALS_MLM'] = 'mosslanding';
        campus['01CALS_UNO'] = 'northridge';
        campus['01CALS_PUP'] = 'pomona';
        campus['01CALS_USL'] = 'sacramento';
        campus['01CALS_USB'] = 'sanbernardino';
        campus['01CALS_SDL'] = 'sandiego';
        campus['01CALS_SFR'] = 'sanfrancisco';
        campus['01CALS_SJO'] = 'sanjose';
        campus['01CALS_PSU'] = 'slo';
        campus['01CALS_USM'] = 'sanmarcos';
        campus['01CALS_SOL'] = 'sonoma';
        campus['01CALS_UST'] = 'stanislaus';

        return 'custom/CENTRAL_PACKAGE/img/one-search/' + campus[vid] + '.png';
    };
}]);

app.component('prmSearchBarAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'prmSearchBarAfterController',
    templateUrl: 'custom/CENTRAL_PACKAGE/html/prmSearchBarAfter.html'
});

/**
 * Resolve duplicate source codes
 */

app.controller('prmServiceDetailsAfterController', ['$location', function ($location) {
    /**
     * Resolve duplicate source codes
     * takes first source code instance and removes additional characters
     * @return {string} source code name
     */
    this.getSourceName = function () {

        // primo central record
        if (this.parentCtrl.item.context == "PC") {
            return this.parentCtrl.item.pnx.display.source[0];
        }

        // alma records; show only first, sans identifier code
        return this.parentCtrl.item.pnx.display.source[0].replace(/\$\$V/g, "").replace(/\$\$O01CALS_ALMA/g, '').replace(/[0-9]/g, '');
    };

    /**
     * Earlier title link
     * @return {string}
     */
    this.getLateralTitleLink = function (title) {

        var params = $location.search();
        var vid = params.vid;
        var query = encodeURI('title,exact,' + title + ',AND');
        var url = '/primo-explore/search?query=' + query + '&vid=' + vid + '&mode=advanced';
        return url;
    };
}]);

app.component('prmServiceDetailsAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'prmServiceDetailsAfterController',
    templateUrl: 'custom/CENTRAL_PACKAGE/html/prmServiceDetailsAfter.html'
});

/**
 * Show My Account and Sign In without extra click
 */

app.component('prmUserAreaAfter', {
    bindings: { parentCtrl: '<' },
    controller: function controller($compile, $scope, $templateCache, $element) {
        $templateCache.put('components/search/topbar/userArea/user-area.html', '\n\t\t  <div class="md-fab-toolbar-wrapper">\n\t\t    <md-toolbar hide-xs>\n\t\t      <md-fab-actions class="md-toolbar-tools zero-padding buttons-group">\n\t\t        <prm-library-card-menu></prm-library-card-menu>\n\t\t        <prm-authentication layout="flex" [is-logged-in]="$ctrl.userName().length > 0"></prm-authentication>\n\t\t      </md-fab-actions>\n\t\t    </md-toolbar>\n\t\t    <md-button class="mobile-menu-button zero-margin" aria-label="{{\'nui.aria.userarea.open\' | translate}}" (click)="$ctrl.enableMobileMenu()" style="min-width: 60px" hide-gt-xs>\n\t\t      <prm-icon [icon-type]="::$ctrl.topBarIcons.more.type" [svg-icon-set]="::$ctrl.topBarIcons.more.iconSet" [icon-definition]="::$ctrl.topBarIcons.more.icon"></prm-icon>\n\t\t    </md-button>\n\t\t  </div>');
        $compile($element.parent())($scope);
    }
});
})();