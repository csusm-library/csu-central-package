(function(){
"use strict";
'use strict';

var app = angular.module('centralCustom', ['angularLoad']);

angular.module('multipleAnalytics', []);
angular.module('multipleAnalytics').run(function ($rootScope, $interval, analyticsOptions, analyticsOptionsDefault) {
  var enabled = analyticsOptions.hasOwnProperty("enabled") ? analyticsOptions.enabled : analyticsOptionsDefault.enabled;
  var siteSource = analyticsOptions.hasOwnProperty("siteSource") ? analyticsOptions.siteSource : analyticsOptionsDefault.siteSource;
  var siteId = analyticsOptions.hasOwnProperty("siteId") ? analyticsOptions.siteId : analyticsOptionsDefault.siteId;
  var siteUrl = analyticsOptions.hasOwnProperty("siteUrl") ? analyticsOptions.siteUrl : analyticsOptionsDefault.siteUrl;
  var defaultTitle = analyticsOptions.hasOwnProperty("defaultTitle") ? analyticsOptions.defaultTitle : analyticsOptionsDefault.defaultTitle;
  if (enabled) {
    if (siteId != '') {
      if (siteSource === 'ga') {
        if (typeof ga === 'undefined') {
          (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;i[r] = i[r] || function () {
              (i[r].q = i[r].q || []).push(arguments);
            }, i[r].l = 1 * new Date();a = s.createElement(o), m = s.getElementsByTagName(o)[0];a.async = 1;a.src = g;m.parentNode.insertBefore(a, m);
          })(window, document, 'script', siteUrl, 'ga');

          ga('create', siteId, { 'alwaysSendReferrer': true });
          ga('set', 'anonymizeIp', true);
        }
      } else if (siteSource === 'matomo') {
        if (siteUrl != '') {
          if (typeof _paq === 'undefined') {
            window['_paq'] = [];
            _paq.push(["setDomains", ["*.csudh-primo.hosted.exlibrisgroup.com/"]]);
            _paq.push(["setDoNotTrack", true]);
            (function () {
              _paq.push(['setTrackerUrl', siteUrl + 'piwik.php']);
              _paq.push(['setSiteId', siteId]);
              var d = document,
                  g = d.createElement('script'),
                  s = d.getElementsByTagName('script')[0];
              g.type = 'text/javascript';g.async = true;g.defer = true;g.src = siteUrl + 'piwik.js';s.parentNode.insertBefore(g, s);
            })();
          }
        }
      }
    }
    $rootScope.$on('$locationChangeSuccess', function (event, toState, fromState) {
      if (siteSource != '') {
        var documentTitle = defaultTitle;
        var timerStart = Date.now();
        var interval = $interval(function () {
          if (document.title !== '') documentTitle = document.title;
          if (window.location.pathname.indexOf('openurl') !== -1 || window.location.pathname.indexOf('fulldisplay') !== -1) if (angular.element(document.querySelector('prm-full-view-service-container .item-title>a')).length === 0) return;else documentTitle = angular.element(document.querySelector('prm-full-view-service-container .item-title>a')).text();

          if (siteSource === 'ga') {
            if (typeof ga !== 'undefined') {
              if (fromState != toState) ga('set', 'referrer', fromState);
              ga('set', 'location', toState);
              ga('set', 'title', documentTitle);
              ga('send', 'pageview');
            }
          } else if (siteSource === 'matomo') {
            if (typeof _paq !== 'undefined') {
              if (fromState != toState) _paq.push(['setReferrerUrl', fromState]);
              _paq.push(['setCustomUrl', toState]);
              _paq.push(['setDocumentTitle', documentTitle]);
              _paq.push(['setGenerationTimeMs', Date.now() - timerStart]);
              _paq.push(['enableLinkTracking']);
              _paq.push(['enableHeartBeatTimer']);
              _paq.push(['trackPageView']);
            }
          }
          $interval.cancel(interval);
        }, 0);
      }
    });
  }
});
angular.module('multipleAnalytics').value('analyticsOptions', {}).value('analyticsOptionsDefault', {
  enabled: false,
  siteSource: 'ga',
  siteId: '',
  siteUrl: 'https://www.google-analytics.com/analytics.js',
  defaultTitle: 'Discovery Search'
});

angular.module('reportProblem', []);

angular.module('reportProblem').component('ocaReportProblem', {
  bindings: {
    messageText: '@',
    buttonText: '@',
    submitText: '@',
    reportUrl: '@',
    reportVendor: '@',
    alertLocation: '@',
    parentCtrl: '<'
  },
  require: {
    itemCtrl: '^prmFullViewServiceContainer'
  },
  template: '\n  <div ng-if="$ctrl.show" class="bar filter-bar layout-align-center-center layout-row margin-top-medium" layout="row" layout-align="center center">\n    <span class="margin-right-small">{{$ctrl.messageText}}</span>\n    <button class="button-with-icon zero-margin md-button md-button-raised md-primoExplore-theme" type="button" aria-label="Report a Problem" ng-click="$ctrl.showReportForm()">\n      <prm-icon icon-type="svg" svg-icon-set="action" icon-definition="ic_report_problem_24px"></prm-icon>\n      <span>{{$ctrl.buttonText}}</span>\n    </button>\n  </div>\n    <div class="alert-panel" ng-show="successMessagebool">\n      <div class="alert-message">\n        Submitted Successfully\n        <button class="md-button md-primoExplore-theme md-ink-ripple" type="button" ng-click="$ctrl.ok()"><span>DISMISS</span><div class="md-ripple-container"></div></button>\n      </div>\n    </div>\n    <div ng-if="$ctrl.showRPForm" class="send-actions-content-item report-problem-form-wrapper" layout="row">\n      <md-content layout-wrap layout-padding layout-fill>\n        <form name="$ctrl.reportForm" novalidate layout="column" layout-align="center center" (submit)="$ctrl.submitReport();">\n          <div layout="row" class="layout-full-width" layout-align="center center">\n            <div flex="10" flex-sm="5" hide-xs></div>\n            <div class="form-focus service-form" layout-padding flex>\n              <div layout-margin>\n                <div layout="column">\n                  <h4 class="md-subhead">Report a Problem</h4>\n                  <md-input-container class="underlined-input" ng-if="$ctrl.requireName">\n                    <label>Name:</label>\n                    <input ng-model="$ctrl.name" name="name" type="text" >\n                    <div ng-messages="reportForm.name.$error">\n                      <div ng-message="required">please enter your name</div>\n                    </div>\n                  </md-input-container>\n                <md-input-container class="underlined-input" ng-if="!$ctrl.requireName">\n                  <label>Name:</label>\n                  <input ng-model="$ctrl.name" name="name" type="text" >\n                </md-input-container>\n                <md-input-container class="underlined-input md-required" ng-if="$ctrl.requireEmail">\n                  <label>Email:</label>\n                  <input ng-model="$ctrl.email" name="email" type="text" required >\n                  <div ng-messages="reportForm.email.$error">\n                    <div ng-message="pattern, required ">email is invalid</div>\n                  </div>\n                </md-input-container>\n                <md-input-container class="underlined-input" ng-if="!$ctrl.requireEmail">\n                  <label>Email:</label>\n                  <input ng-model="$ctrl.email" name="email" type="text" >\n                </md-input-container>\n                <md-input-container class="md-required" ng-if="$ctrl.requireDesc">\n                  <label>Description:</label>\n                  <textarea ng-model="$ctrl.description" name="description" required></textarea>\n                  <div ng-messages="reportForm.description.$error">\n                    <div ng-message="required">please enter your problem description</div>\n                  </div>\n                </md-input-container>\n                <md-input-container ng-if="!$ctrl.requireDesc">\n                  <label>Description:</label>\n                  <textarea ng-model="$ctrl.description" name="description"></textarea>\n                </md-input-container>\n                <md-input-container class="underlined-input" ng-if="$ctrl.isCaptcha">\n                  <div vc-recaptcha key="$ctrl.getCaptchaPublicKey()" on-success="$ctrl.setResponse(response)"></div>\n                  <span class="recaptcha-error-info" ng-show="smsForm.$submitted && ($ctrl.statusCode != 200 || smsForm.recaptchaResponse.$invalid || smsForm.$error.recaptcha.length)">\n                    <span translate="captcha.notselected"></span>\n                  </span>\n                </md-input-container>\n              </div>\n            </div>\n          </div>\n          <div flex="20" flex-sm="10" hide-xs></div>\n        </div>\n        <div layout="row">\n          <div layout="row" layout-align="center" layout-fill>\n            <md-button type="submit" class="button-with-icon button-large button-confirm" aria-label="Submit Report">\n              <prm-icon icon-type="svg" svg-icon-set="primo-ui" icon-definition="send"></prm-icon>\n              <span>{{$ctrl.submitText}}</span>\n            </md-button>\n          </div>\n        </div>\n      </form>\n    </md-content>\n  </div>\n  ',
  controller: ['$location', '$httpParamSerializer', '$http', 'reportProblem', 'reportProblemDefault', '$timeout', '$scope', function ($location, $httpParamSerializer, $http, reportProblem, reportProblemDefault, $timeout, $scope) {
    var _this = this;

    this.enabled = reportProblem.hasOwnProperty("enabled") ? reportProblem.enabled : reportProblemDefault.enabled;
    this.requireName = reportProblem.hasOwnProperty("requireName") ? reportProblem.requireName : reportProblemDefault.requireName;
    this.requireEmail = reportProblem.hasOwnProperty("requireEmail") ? reportProblem.requireEmail : reportProblemDefault.requireEmail;
    this.requireDesc = reportProblem.hasOwnProperty("requireDesc") ? reportProblem.requireDesc : reportProblemDefault.requireDesc;
    this.format = reportProblem.hasOwnProperty("format") ? reportProblem.format : reportProblemDefault.format;
    this.messageText = this.messageText || (reportProblem.hasOwnProperty("messageText") ? reportProblem.messageText : reportProblemDefault.messageText);
    this.buttonText = this.buttonText || (reportProblem.hasOwnProperty("buttonText") ? reportProblem.buttonText : reportProblemDefault.buttonText);
    this.submitText = this.submitText || (reportProblem.hasOwnProperty("submitText") ? reportProblem.submitText : reportProblemDefault.submitText);
    this.reportUrl = this.reportUrl || (reportProblem.hasOwnProperty("reportUrl") ? reportProblem.reportUrl : reportProblemDefault.reportUrl);
    this.reportVendor = this.reportVendor || (reportProblem.hasOwnProperty("reportVendor") ? reportProblem.reportVendor : reportProblemDefault.reportVendor);
    this.alertLocation = this.alertLocation || (reportProblem.hasOwnProperty("alertLocation") ? reportProblem.alertLocation : reportProblemDefault.alertLocation);
    this.showLocations = ['/fulldisplay', '/openurl', '/jfulldisplay'];
    this.$onInit = function () {
      this.targetUrl = this.reportUrl + $httpParamSerializer($location.search());
      this.show = this.showLocations.includes($location.path()) && this.enabled === true;
      this.name = this.email = this.phoneNumber = this.description = this.gCaptchaResponse = this.statusMessage = '';
      this.telRegEx = /^\d{3}( |-)?\d{3}( |-)?\d{4}$/;
      this.emailRegEx = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/; // see http://emailregex.com/
      this.statusCode = 200;
      this.showRPForm = false;
    };
    this.validate = function () {
      return (_this.requireName ? _this.name : true) && (_this.requireEmail ? _this.emailRegEx.test(_this.email) : true) && (_this.requireDesc ? _this.description : true) && (_this.isCaptcha ? _this.gCaptchaResponse : true);
    };
    this.isCaptcha = window.appConfig['system-configuration']['Activate Captcha [Y/N]'] == 'Y';
    this.getCaptchaPublicKey = function () {
      return window.appConfig['system-configuration']['Public Captcha Key'];
    };
    this.setResponse = function (response) {
      return _this.gCaptchaResponse = response;
    };
    this.setStatusCode = function (code) {
      return _this.statusCode = code;
    };
    this.setStatusMessage = function (message) {
      return _this.statusMessage = message;
    };
    this.showReportForm = function () {
      return _this.showRPForm = !_this.showRPForm;
    };
    this.ok = function () {
      $scope.successMessagebool = false;
    };

    this.submitReport = function () {
      if (_this.validate()) {
        var params = {
          'reportVendor': _this.reportVendor,
          'format': _this.format,
          'subject': reportProblem.hasOwnProperty("subject") ? reportProblem.subject : reportProblemDefault.subject,
          'name': _this.name,
          'from': _this.email ? _this.email : reportProblem.hasOwnProperty("from") ? reportProblem.from : reportProblemDefault.from,
          'phone': _this.phoneNumber,
          'description': _this.description,
          'gCaptchaResponse': _this.gCaptchaResponse,
          'addPatronInfo': reportProblem.hasOwnProperty("addPatronInfo") ? reportProblem.addPatronInfo : reportProblemDefault.addPatronInfo,
          'urlBase': $location.protocol() + '://' + $location.host() + ($location.port() != 80 ? ':' + $location.port() : '') + '/primo-explore' + $location.path(),
          'urlParams': $location.search(),
          'item': _this.itemCtrl.item
        };
        params.subject = params.subject.replace(/\{(.+?)(?![^}])\}/g, function (match, p1) {
          function recurFind(data, stack) {
            if (data.indexOf('.') > -1) {
              var parts = data.split(/\.(.+)/);
              if (parts[1].indexOf('.') > -1) {
                var parts2 = parts[1].split(/\.(.+)/);
                if (stack.hasOwnProperty(parts[0])) if (stack[parts[0]].hasOwnProperty(parts2[0])) return recurFind(parts2[1], stack[parts[0]][parts2[0]]);
              } else if (stack.hasOwnProperty(parts[0])) if (stack[parts[0]].hasOwnProperty(parts[1])) return stack[parts[0]][parts[1]];
            } else if (stack.hasOwnProperty(data)) return stack[data];
            return false;
          }
          var rft = recurFind(p1, params.item.pnx);
          if (rft) return rft;
          return match;
        });
        if (_this.reportVendor === 'libanswers') {
          params.action = 'libanswers';
          params.instid = reportProblem.hasOwnProperty("instid") ? reportProblem.instid : reportProblemDefault.instid;
          params.quid = reportProblem.hasOwnProperty("quid") ? reportProblem.quid : reportProblemDefault.quid;
          params.qlog = reportProblem.hasOwnProperty("qlog") ? reportProblem.qlog : reportProblemDefault.qlog;
          params.source = reportProblem.hasOwnProperty("source") ? reportProblem.source : reportProblemDefault.source;
        } else if (_this.reportVendor === 'email') {
          params.action = 'problem-email';
          params.to = reportProblem.hasOwnProperty("to") ? reportProblem.to : reportProblemDefault.to;
        }
        $http.post(_this.reportUrl, params).then(function (msg) {
          _this.setStatusCode(msg.status);
          _this.setStatusMessage(msg.statusText);
          $scope.successMessage = "Submitted successfully";
          $scope.successMessagebool = true;
          $scope.successMessagebool = true;
          $timeout(function () {
            $scope.successMessagebool = false;
          }, 8000);
        }).catch(function (err) {
          _this.setStatusCode(err.status);
          _this.setStatusMessage(err.statusText);
          _this.setResponse('');
          if (typeof grecaptcha !== 'undefined') grecaptcha.reset();
          alert('report sending failed');
        }).finally(function () {
          if (_this.statusCode == 200) {
            _this.name = _this.email = _this.phoneNumber = _this.description = _this.gCaptchaResponse = _this.statusMessage = '';
            _this.reportForm.$setPristine();
            _this.reportForm.$setUntouched();
            _this.showReportForm();
          }
        });
      }
    };
  }]
}).run(['$templateCache', 'reportProblem', 'reportProblemDefault', function ($templateCache, reportProblem, reportProblemDefault) {
  if (reportProblem.hasOwnProperty("enabledDefault") ? reportProblem.enabledDefault : reportProblemDefault.enabledDefault) {
    var alertLocation = reportProblem.hasOwnProperty("alertLocation") ? reportProblem.alertLocation : reportProblemDefault.alertLocation;
    $templateCache.put('components/search/fullView/fullViewServiceContainer/full-view-service-container.html', $templateCache.get('components/search/fullView/fullViewServiceContainer/full-view-service-container.html').replace('</' + alertLocation + '>', '</' + alertLocation + '><oca-report-problem ng-if="$ctrl.index == 1 && $ctrl.service.serviceName===\'activate\'" parent-ctrl="$ctrl"></oca-report-problem>') // get/view it
    .replace('<prm-full-view-service-container-after', '<oca-report-problem ng-if="$ctrl.index == 1 && $ctrl.service.serviceName!==\'activate\'" parent-ctrl="$ctrl"></oca-report-problem><prm-full-view-service-container-after')); // everything else catch-all
  }
}]);

angular.module('reportProblem').value('reportProblem', {}).value('reportProblemDefault', {
  enabled: false,
  enabledDefault: true,
  requireName: false,
  requireEmail: true,
  requireDesc: true,
  format: 'html', //html | plaintext | markdown
  reportUrl: 'https://library.calstate.edu/primo-gateway/',
  reportVendor: 'email',
  alertLocation: 'prm-login-alma-mashup',
  messageText: 'See something that doesn\'t look right?',
  buttonText: 'Report a Problem',
  submitText: 'Report',
  subject: 'Problem report',
  to: '',
  from: 'donotreply@calstate.edu',
  addPatronInfo: false,
  instid: '',
  quid: '',
  qlog: '',
  source: ''
});

angular.module('customActions', []);

/* eslint-disable max-len */
angular.module('customActions').component('customAction', {
  bindings: {
    name: '@',
    label: '@',
    expandable: '@',
    icon: '@',
    iconSet: '@',
    link: '@',
    index: '<'
  },
  require: {
    prmActionCtrl: '^prmActionList'
  },
  controller: ['customActions', function (customActions) {
    var _this = this;

    this.$onInit = function () {
      _this.action = {
        name: _this.name,
        label: _this.label,
        index: _this.index,
        expandable: _this.expandable,
        icon: {
          icon: _this.icon,
          iconSet: _this.iconSet,
          type: 'svg'
        },
        onToggle: customActions.processLinkTemplate(_this.link, _this.prmActionCtrl.item)
      };
      customActions.addAction(_this.action, _this.prmActionCtrl);
    };
    this.$onDestroy = function () {
      return customActions.removeAction(_this.action, _this.prmActionCtrl);
    };
  }]
});

/* eslint-disable max-len */
angular.module('customActions').factory('customActions', function () {
  return {
    /**
     * Adds an action to the actions menu, including its icon.
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     */
    // TODO coerce action.index to be <= requiredActionsList.length
    addAction: function addAction(action, ctrl) {
      if (!this.actionExists(action, ctrl)) {
        this.addActionIcon(action, ctrl);
        ctrl.actionListService.requiredActionsList.splice(action.index, 0, action.name);
        ctrl.actionListService.actionsToIndex[action.name] = action.index;
        ctrl.actionListService.onToggle[action.name] = action.onToggle;
        ctrl.actionListService.actionsToDisplay.unshift(action.name);
        ctrl.expandableActions[action.name] = action.expandable;
      }
    },
    /**
     * Removes an action from the actions menu, including its icon.
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     */
    removeAction: function removeAction(action, ctrl) {
      if (this.actionExists(action, ctrl)) {
        this.removeActionIcon(action, ctrl);
        delete ctrl.actionListService.actionsToIndex[action.name];
        delete ctrl.actionListService.onToggle[action.name];
        delete ctrl.expandableActions[action.expandable];
        var i = ctrl.actionListService.actionsToDisplay.indexOf(action.name);
        ctrl.actionListService.actionsToDisplay.splice(i, 1);
        i = ctrl.actionListService.requiredActionsList.indexOf(action.name);
        ctrl.actionListService.requiredActionsList.splice(i, 1);
      }
    },
    /**
     * Registers an action's icon.
     * Called internally by addAction().
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     */
    addActionIcon: function addActionIcon(action, ctrl) {
      ctrl.actionLabelNamesMap[action.name] = action.label;
      ctrl.actionIconNamesMap[action.name] = action.name;
      ctrl.actionIcons[action.name] = action.icon;
    },
    /**
     * Deregisters an action's icon.
     * Called internally by removeAction().
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     */
    removeActionIcon: function removeActionIcon(action, ctrl) {
      delete ctrl.actionLabelNamesMap[action.name];
      delete ctrl.actionIconNamesMap[action.name];
      delete ctrl.actionIcons[action.name];
    },
    /**
     * Check if an action exists.
     * Returns true if action is part of actionsToIndex.
     * @param  {object} action  action object
     * @param  {object} ctrl    instance of prmActionCtrl
     * @return {bool}
     */
    actionExists: function actionExists(action, ctrl) {
      return ctrl.actionListService.actionsToIndex.hasOwnProperty(action.name);
    },
    /**
     * Process a link into a function to call when the action is clicked.
     * The function will open the processed link in a new tab.
     * Will replace {pnx.xxx.xxx} expressions with properties from the item.
     * @param  {string}    link    the original link string from the html
     * @param  {object}    item    the item object obtained from the controller
     * @return {function}          function to call when the action is clicked
     */
    processLinkTemplate: function processLinkTemplate(link, item) {
      var processedLink = link;
      var pnxProperties = link.match(/\{(pnx\..*?)\}/g) || [];
      pnxProperties.forEach(function (property) {
        var value = property.replace(/[{}]/g, '').split('.').reduce(function (o, i) {
          try {
            var h = /(.*)(\[\d\])/.exec(i);
            if (h instanceof Array) {
              return o[h[1]][h[2].replace(/[^\d]/g, '')];
            }
            return o[i];
          } catch (e) {
            return '';
          }
        }, item);
        processedLink = processedLink.replace(property, value);
      });
      return function () {
        return window.open(processedLink, '_blank');
      };
    }
  };
});

angular.module('sendSms', ['ngMaterial', 'primo-explore.components', 'customActions']);

angular.module('sendSms').component('ocaSendSms', {
  bindings: {
    item: '<',
    finishedSmsEvent: '&'
  },
  template: '\n  <div class="send-actions-content-item" layout="row">\n    <md-content layout-wrap layout-padding layout-fill>\n      <form name="smsForm" novalidate layout="column" layout-align="center center" (submit)="$ctrl.sendSms($event);">\n        <div layout="row" class="layout-full-width" layout-align="center center">\n          <div flex="20" flex-sm="10" hide-xs></div>\n          <div class="form-focus service-form" layout-padding flex>\n            <div layout-margin>\n              <div layout="column">\n                <h4 class="md-subhead">Standard message and data rates may apply.</h4>\n                <md-input-container class="underlined-input md-required">\n                  <label>Phone number:</label>\n                  <input ng-model="$ctrl.phoneNumber" name="phoneNumber" type="text" required ng-pattern="::$ctrl.telRegEx">\n                  <div ng-messages="smsForm.phoneNumber.$error">\n                    <div ng-message="pattern, required ">phone number is invalid</div>\n                  </div>\n                </md-input-container>\n                <md-input-container class="md-required">\n                  <label>Carrier:</label>\n                  <md-select ng-model="$ctrl.carrier" name="carrier" placeholder="Select a carrier" required>\n                    <md-option ng-repeat="(carrier, address) in $ctrl.carriers" value="{{ address }}">\n                      {{ carrier }}\n                    </md-option>\n                  </md-select>\n                  <div ng-messages="smsForm.carrier.$error">\n                    <div ng-message="required">please select a carrier</div>\n                  </div>\n                </md-input-container>\n                <md-input-container class="underlined-input" ng-if="$ctrl.isCaptcha">\n                  <div vc-recaptcha key="$ctrl.getCaptchaPublicKey()" on-success="$ctrl.setResponse(response)"></div>\n                  <span class="recaptcha-error-info" ng-show="smsForm.$submitted && ($ctrl.statusCode != 200 || smsForm.recaptchaResponse.$invalid || smsForm.$error.recaptcha.length)">\n                    <span translate="captcha.notselected"></span>\n                  </span>\n                </md-input-container>\n                <md-input-container class="underlined-input" ng-show="$ctrl.statusCode != 200">\n                  <span class="recaptcha-error-info" ng-show="$ctrl.statusCode != 200">\n                    <span>{{$ctrl.statusMessage}}</span>\n                  </span>\n                </md-input-container>\n              </div>\n            </div>\n          </div>\n          <div flex="20" flex-sm="10" hide-xs></div>\n        </div>\n        <div layout="row">\n          <div layout="row" layout-align="center" layout-fill>\n            <md-button type="submit" class="button-with-icon button-large button-confirm" aria-label="Send the result by SMS">\n              <prm-icon icon-type="svg" svg-icon-set="primo-ui" icon-definition="send"></prm-icon>\n              <span translate="email.popup.link.send"></span>\n            </md-button>\n          </div>\n        </div>\n      </form>\n    </md-content>\n  </div>\n  <oca-send-sms-after parent-ctrl="$ctrl"></oca-send-sms-after>\n  ',
  controller: ['$http', 'smsCarriers', 'smsCarriersDefault', 'smsOptions', 'smsOptionsDefault', function ($http, smsCarriers, smsCarriersDefault, smsOptions, smsOptionsDefault) {
    var _this = this;

    this.noPrintFoundLabel = smsOptions.hasOwnProperty("noPrintFoundLabel") ? smsOptions.noPrintFoundLabel : smsOptionsDefault.noPrintFoundLabel;
    this.$onInit = function () {
      _this.carriers = angular.equals(smsCarriers, {}) ? smsCarriersDefault : smsCarriers;
      _this.carrier = _this.phoneNumber = _this.gCaptchaResponse = _this.statusMessage = '';
      _this.telRegEx = /^\d{3}( |-)?\d{3}( |-)?\d{4}$/;
      _this.statusCode = 200;
    };
    this.validate = function () {
      return _this.telRegEx.test(_this.phoneNumber) && _this.carrier && (_this.isCaptcha ? _this.gCaptchaResponse : true);
    };
    this.isCaptcha = window.appConfig['system-configuration']['Activate Captcha [Y/N]'] == 'Y';
    this.getCaptchaPublicKey = function () {
      return window.appConfig['system-configuration']['Public Captcha Key'];
    };
    this.setResponse = function (response) {
      return _this.gCaptchaResponse = response;
    };
    this.setStatusCode = function (code) {
      return _this.statusCode = code;
    };
    this.setStatusMessage = function (message) {
      return _this.statusMessage = message;
    };
    this.sendSms = function () {
      if (_this.validate()) {
        var message = "";
        var title = 'Title: ' + _this.item.pnx.display.title;
        if (_this.item.delivery.holding.length > 0) {
          var holdings = '';
          _this.item.delivery.holding.forEach(function (holding) {
            if (holding.organization == appConfig['primo-view']['institution']['institution-code']) {
              if (holdings != '') holdings += '<br><br>';
              holdings += 'Location: ' + holding.subLocation + '<br>';
              holdings += 'Call Number: ' + holding.callNumber + '<br>';
              holdings += 'Currently ' + holding.availabilityStatus;
            }
          });
          if (holdings == '') {
            holdings = _this.noPrintFoundLabel;
          }
          // make sure we don't exceed 160 (148 chars + stuff)
          if (title.length + holdings.length > 148) {
            title = title.substring(0, 148 - holdings.length) + '...';
          }
          message = title + '<br><br>' + holdings;
          console.log("SMS length: " + message.length);
        } else message += _this.noPrintFoundLabel;
        $http.post(smsOptions.formUrl || smsOptionsDefault.formUrl, {
          "action": "sms",
          "from": smsOptions.fromEmail || smsOptionsDefault.fromEmail,
          "to": _this.phoneNumber + '@' + _this.carrier,
          "subject": smsOptions.subject || smsOptionsDefault.subject,
          "message": message,
          "gCaptchaResponse": _this.gCaptchaResponse
        }).then(function (msg) {
          _this.setStatusCode(msg.status);
          _this.setStatusMessage(msg.statusText);
          console.log('sms successfully sent', msg);
        }).catch(function (err) {
          _this.setStatusCode(err.status);
          _this.setStatusMessage(err.statusText);
          _this.setResponse('');
          if (typeof grecaptcha !== 'undefined') grecaptcha.reset();
          console.error('sms sending failed', err);
        }).finally(function () {
          return _this.statusCode == 200 ? _this.finishedSmsEvent() : '';
        });
      }
    };
  }]
}).run(['$templateCache', 'smsAction', 'smsActionDefault', 'smsOptions', 'smsOptionsDefault', function ($templateCache, smsAction, smsActionDefault, smsOptions, smsOptionsDefault) {
  if (smsOptions.hasOwnProperty("enabled") ? smsOptions.enabled : smsOptionsDefault.enabled) {
    $templateCache.put('components/search/actions/actionContainer/action-container.html', '<oca-send-sms ng-if="($ctrl.actionName===\'' + (smsAction.name || smsActionDefault.name) + '\')" finished-sms-event="$ctrl.throwCloseTabsEvent()" item="::$ctrl.item"></oca-send-sms>' + $templateCache.get('components/search/actions/actionContainer/action-container.html'));
    $templateCache.put('components/search/actions/action-list.html', $templateCache.get('components/search/actions/action-list.html').replace('</md-nav-item>', '</md-nav-item><sms-action />'));
  }
}]);

angular.module('sendSms').component('smsAction', {
  require: {
    prmActionCtrl: '^prmActionList'
  },
  controller: ['customActions', 'smsAction', 'smsActionDefault', 'smsOptions', function (customActions, smsAction, smsActionDefault, smsOptions) {
    var _this2 = this;

    smsAction.name = smsOptions.name || smsActionDefault.name;
    smsAction.label = smsOptions.label || smsActionDefault.label;
    smsAction.expandable = smsOptions.expandable || smsActionDefault.expandable;
    smsAction.index = smsOptions.index || smsActionDefault.index;
    smsAction.icon = smsOptions.icon || smsActionDefault.icon;

    this.$onInit = function () {
      return customActions.addAction(smsAction, _this2.prmActionCtrl);
    };
    this.$onDestroy = function () {
      return customActions.removeAction(smsAction, _this2.prmActionCtrl);
    };
  }]
});

angular.module('sendSms').value('smsAction', {}).value('smsActionDefault', {
  name: 'send_sms',
  label: 'Text',
  expandable: true,
  index: 9,
  icon: {
    icon: 'ic_smartphone_24px',
    iconSet: 'hardware',
    type: 'svg'
  }
}).value('smsCarriers', {}).value('smsCarriersDefault', {
  'ATT': 'sms.att.net',
  'Boost': 'sms.myboostmobile.com',
  'Cricket': 'mms.mycricket.com',
  'Nextel': 'messaging.nextel.com',
  'Project Fi': 'msg.fi.google.com',
  'Qwest': 'qwestmp.com',
  'Sprint': 'messaging.sprintpcs.com',
  'T-Mobile': 'tmomail.net',
  'Verizon': 'vtext.com',
  'Virgin': 'vmobl.com'
}).value('smsOptions', {}).value('smsOptionsDefault', {
  enabled: false,
  formUrl: 'https://library.calstate.edu/primo-gateway/',
  fromEmail: 'do-not-respond@calstate.edu',
  subject: '',
  noPrintFoundLabel: 'No Print Locations'
});

/**
 * Collapse institution list in full record
 */

app.controller('institutionToggleController', ['$scope', function ($scope) {
  /**
   * On page load, hide libraries
   */
  this.$onInit = function () {
    $scope.showLibs = false;
    $scope.button = angular.element(document.querySelector('prm-alma-more-inst-after'));
    $scope.tabs = angular.element(document.querySelector('prm-alma-more-inst md-tabs'));
    $scope.tabs.addClass('hide');
    $scope.button.after($scope.tabs);
  };

  /**
   * Show or hide library based on previous state
   */
  $scope.toggleLibs = function () {
    $scope.showLibs = !$scope.showLibs;
    if ($scope.tabs.hasClass('hide')) $scope.tabs.removeClass('hide');else $scope.tabs.addClass('hide');
  };
}]);

app.component('prmAlmaMoreInstAfter', {
  bindings: { parentCtrl: '<' },
  controller: 'institutionToggleController',
  templateUrl: 'custom/01CALS_NETWORK-CENTRAL_PACKAGE/html/prmAlmaMoreInstAfter.html'
});

/**
 * Collapse institution list in full record for Primo VE
 */

app.controller('prmAlmaOtherMembersAfterController', [function () {
  var vm = this.parentCtrl;

  /**
   * On page load, hide libraries
   */
  this.$onInit = function () {
    vm.isCollapsed = true;
  };
}]);

app.component('prmAlmaOtherMembersAfter', {
  bindings: {
    parentCtrl: '<'
  },
  controller: 'prmAlmaOtherMembersAfterController',
  template: ''
});

/**
 * Remove course reserves icon
 */

app.controller('prmBriefResultContainerAfterController', [function () {
  var vm = this.parentCtrl;

  Object.defineProperty(vm, "isCourseDocument", {
    get: function get() {
      return vm.item.pnx.display.hasOwnProperty("crsinfo") ? vm.item.pnx.display.crsinfo[0].includes(vm.institutionCode) : false;
    }
  });
}]);

app.component('prmBriefResultContainerAfter', {
  bindings: {
    parentCtrl: '<'
  },
  controller: 'prmBriefResultContainerAfterController',
  template: ''
});

/**
 * CSU OneSearch logo
 */

app.controller('prmSearchBarAfterController', ['$location', '$window', function ($location, $window) {
  /**
   * Navigates to the home page with a reload.
   * @return {boolean} Booelan value indicating if the navigation was successful.
   */
  this.navigateToHomePage = function () {
    var params = $location.search();
    var vid = params.vid;
    var lang = params.lang || "en_US";
    var split = $location.absUrl().split('/discovery/');

    if (split.length === 1) {
      console.log(split[0] + ' : Could not detect the view name!');
      return false;
    }

    var baseUrl = split[0];
    $window.location.href = baseUrl + '/discovery/search?vid=' + vid + '&lang=' + lang;
    return true;
  };

  /**
   * OneSearch logo
   * @return {string} URI to the one-search logo file in the current view
   */
  this.getOneSearchLogo = function () {
    var params = $location.search();
    var vid = params.vid.substring(0, 10);
    var campus = {};
    campus['01CALS_UBA'] = 'bakersfield';
    campus['01CALS_UCI'] = 'channel';
    campus['01CALS_CHI'] = 'chico';
    campus['01CALS_UDH'] = 'dominguez';
    campus['01CALS_UHL'] = 'eastbay';
    campus['01CALS_UFR'] = 'fresno';
    campus['01CALS_FUL'] = 'fullerton';
    campus['01CALS_HUL'] = 'humboldt';
    campus['01CALS_ULB'] = 'longbeach';
    campus['01CALS_ULA'] = 'losangeles';
    campus['01CALS_MAL'] = 'maritime';
    campus['01CALS_UMB'] = 'monterey';
    campus['01CALS_MLM'] = 'mosslanding';
    campus['01CALS_UNO'] = 'northridge';
    campus['01CALS_PUP'] = 'pomona';
    campus['01CALS_USL'] = 'sacramento';
    campus['01CALS_USB'] = 'sanbernardino';
    campus['01CALS_SDL'] = 'sandiego';
    campus['01CALS_SFR'] = 'sanfrancisco';
    campus['01CALS_SJO'] = 'sanjose';
    campus['01CALS_PSU'] = 'slo';
    campus['01CALS_USM'] = 'sanmarcos';
    campus['01CALS_SOL'] = 'sonoma';
    campus['01CALS_UST'] = 'stanislaus';

    return 'custom/01CALS_NETWORK-CENTRAL_PACKAGE/img/one-search/' + campus[vid] + '.png';
  };
}]);

app.component('prmSearchBarAfter', {
  bindings: { parentCtrl: '<' },
  controller: 'prmSearchBarAfterController',
  templateUrl: 'custom/01CALS_NETWORK-CENTRAL_PACKAGE/html/prmSearchBarAfter.html'
});
})();