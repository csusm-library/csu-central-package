(function(){
"use strict";
'use strict';

var app = angular.module('centralCustom', ['angularLoad']);

/**
 * Collapse institution list in full record
 */

app.controller('institutionToggleController', ['$scope', function ($scope) {
    /**
     * On page load, hide libraries
     */
    this.$onInit = function () {
        $scope.showLibs = false;
        $scope.button = angular.element(document.querySelector('prm-alma-more-inst-after'));
        $scope.tabs = angular.element(document.querySelector('prm-alma-more-inst md-tabs'));
        $scope.tabs.addClass('hide');
        $scope.button.after($scope.tabs);
    };

    /**
     * Show or hide library based on previous state
     */
    $scope.toggleLibs = function () {
        $scope.showLibs = !$scope.showLibs;
        if ($scope.tabs.hasClass('hide')) $scope.tabs.removeClass('hide');else $scope.tabs.addClass('hide');
    };
}]);

app.component('prmAlmaMoreInstAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'institutionToggleController',
    templateUrl: 'custom/CENTRAL_PACKAGE/html/prmAlmaMoreInstAfter.html'
});

/**
 * CSU OneSearch logo
 */

app.controller('prmSearchBarAfterController', ['$location', '$window', function ($location, $window) {
    /**
     * Navigates to the home page with a reload.
     * @return {boolean} Booelan value indicating if the navigation was successful.
     */
    this.navigateToHomePage = function () {
        var params = $location.search();
        var vid = params.vid;
        var lang = params.lang || "en_US";
        var split = $location.absUrl().split('/primo-explore/');

        if (split.length === 1) {
            console.log(split[0] + ' : Could not detect the view name!');
            return false;
        }

        var baseUrl = split[0];
        $window.location.href = baseUrl + '/primo-explore/search?vid=' + vid + '&lang=' + lang;
        return true;
    };

    /**
     * OneSearch logo
     * @return {string} URI to the one-search logo file in the current view
     */
    this.getOneSearchLogo = function () {
        var params = $location.search();
        var vid = params.vid.substring(0, 10);
        var campus = {};
        campus['01CALS_UBA'] = 'bakersfield';
        campus['01CALS_UCI'] = 'channel';
        campus['01CALS_CHI'] = 'chico';
        campus['01CALS_UDH'] = 'dominguez';
        campus['01CALS_UHL'] = 'eastbay';
        campus['01CALS_UFR'] = 'fresno';
        campus['01CALS_FUL'] = 'fullerton';
        campus['01CALS_HUL'] = 'humboldt';
        campus['01CALS_ULB'] = 'longbeach';
        campus['01CALS_ULA'] = 'losangeles';
        campus['01CALS_MAL'] = 'maritime';
        campus['01CALS_UMB'] = 'monterey';
        campus['01CALS_MLM'] = 'mosslanding';
        campus['01CALS_UNO'] = 'northridge';
        campus['01CALS_PUP'] = 'pomona';
        campus['01CALS_USL'] = 'sacramento';
        campus['01CALS_USB'] = 'sanbernardino';
        campus['01CALS_SDL'] = 'sandiego';
        campus['01CALS_SFR'] = 'sanfrancisco';
        campus['01CALS_SJO'] = 'sanjose';
        campus['01CALS_PSU'] = 'slo';
        campus['01CALS_USM'] = 'sanmarcos';
        campus['01CALS_SOL'] = 'sonoma';
        campus['01CALS_UST'] = 'stanislaus';

        return 'custom/CENTRAL_PACKAGE/img/one-search/' + campus[vid] + '.png';
    };
}]);

app.component('prmSearchBarAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'prmSearchBarAfterController',
    templateUrl: 'custom/CENTRAL_PACKAGE/html/prmSearchBarAfter.html'
});

// prm-service-details-after-controller

app.controller('prmSearchResultThumbnailContainerAfterController', [function () {
    /**
     * Get thumbnail URL
     * @return {string} relative path to thumbnail url
     */
    this.getIconSource = function () {
        // 'custom/CENTRAL_PACKAGE/'
        return this.parentCtrl.selectedThumbnailLink.linkURL;
    };
}]);

app.component('prmSearchResultThumbnailContainerAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'prmSearchResultThumbnailContainerAfterController',
    templateUrl: 'custom/CENTRAL_PACKAGE/html/prmSearchResultThumbnailContainerAfter.html'
});

/**
 * Resolve duplicate source codes
 */

app.controller('prmServiceDetailsAfterController', [function () {
    /**
     * Resolve duplicate source codes
     * takes first source code instance and removes additional characters
     * @return {string} source code name
     */
    this.getSourceName = function () {

        // primo central record
        if (this.parentCtrl.item.context == "PC") {
            return this.parentCtrl.item.pnx.display.source[0];
        }

        // alma records; show only first, sans identifier code
        return this.parentCtrl.item.pnx.display.source[0].replace(/\$\$V/g, "").replace(/\$\$O01CALS_ALMA/g, '').replace(/[0-9]/g, '');
    };
}]);

app.component('prmServiceDetailsAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'prmServiceDetailsAfterController',
    templateUrl: 'custom/CENTRAL_PACKAGE/html/prmServiceDetailsAfter.html'
});

/**
 * Show My Account and Sign In without extra click
 */

app.component('prmUserAreaAfter', {
    bindings: { parentCtrl: '<' },
    controller: function controller($compile, $scope, $templateCache, $element) {
        $templateCache.put('components/search/topbar/userArea/user-area.html', '\n          <div layout=\'row\' layout-align="center center">\n            <prm-library-card-menu></prm-library-card-menu>\n            <prm-authentication layout="flex" [is-logged-in]="$ctrl.userName().length > 0"></prm-authentication>\n          </div>');
        $compile($element.parent())($scope);
    }
});
})();